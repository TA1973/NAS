﻿using System;
using System.Web.UI;

namespace National_Weather_Service
{
    public partial class DisplayWeather : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    //Get the Weather Forcast for Number 3
                    int iNum = Convert.ToInt32(Request.QueryString["num"]);
                    WeatherForcast weather = WeatherForcast.GetWeather(iNum);
                    if (weather == null)
                    {
                        lblJsonMessage.Text = "Cannot Retrieve Current Weather";
                    }
                    else
                    {
                        //Display the Values for the Current Weather
                        lblImage.Text = "<img src='" + weather.icon + "'/>";
                        lblNumber.Text = "Current Weather for Number " + iNum.ToString();
                        lblTemperature.Text = weather.temperature.ToString();
                        lblTempUnit.Text = weather.temperatureUnit;
                        lblWindSpeed.Text = weather.windSpeed;

                        //Populate the Detailed fields
                        lblDirection.Text = weather.windDirection;
                        lblShort.Text = weather.shortForecast;
                        
                    }
                }
                catch (Exception ex)
                {
                    lblJsonMessage.Text = ex.Message.ToString();
                }
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnCheck_Click(object sender, EventArgs e)
        {
            Response.Redirect("DisplayWeather.aspx?num=" + txtNumber.Text );
        }
    }
}