﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace National_Weather_Service
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            lblLoginMessage.Visible = true;
            try
            {
                //Connect to the Database
                SqlConnection dbConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString);
                SqlCommand sqlQuery = null;
                dbConnection.Open();

                //Check for Unique User Name
                sqlQuery = new SqlCommand("select COUNT(UserName) From Registration WHERE UserName = '" + txtUserName.Text + "' AND Password = '" + txtPassword.Text + "'", dbConnection);
                Int32 countUserName = (Int32)sqlQuery.ExecuteScalar();

                if (countUserName == 1)
                {
                    //Login Successful Redirect User to see the weather
                    Response.Redirect("DisplayWeather.aspx?num=3");
                }
                else
                {
                    lblLoginMessage.Text = "Invalid UserName and Password";
                }

            }
            catch (Exception ex)
            {
                lblLoginMessage.Text = "Could Not Login " + ex.Message.ToString() + ". Please Try again Later";
            }

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }
    }
}