﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace National_Weather_Service
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            lblRegistrationMessage.Visible = true;
            try
            {
                //Connect to the Database
                SqlConnection dbConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString);
                SqlCommand sqlQuery = null;
                dbConnection.Open();

                //Check for Unique User Name
                sqlQuery = new SqlCommand("select COUNT(UserName) From Registration WHERE UserName = '" + txtUserName.Text + "'", dbConnection);
                Int32 countUserName = (Int32)sqlQuery.ExecuteScalar();
                
                if (countUserName == 0)
                {
                    //Check for Unique Email
                    sqlQuery = new SqlCommand("select COUNT(Email) From Registration WHERE Email = '" + txtEmail.Text + "'", dbConnection);
                    Int32 countEmail = (Int32)sqlQuery.ExecuteScalar();
                    if (countEmail == 0)
                    {
                        //Register User if UserName and Email are unique
                        sqlQuery = new SqlCommand("insert into Registration values (@UserName, @Email, @Password)", dbConnection);
                        sqlQuery.Parameters.AddWithValue("UserName", txtUserName.Text);
                        sqlQuery.Parameters.AddWithValue("Email", txtEmail.Text);
                        sqlQuery.Parameters.AddWithValue("Password", txtPassword.Text);
                        sqlQuery.ExecuteNonQuery();
                        lblRegistrationMessage.Text = "Registration Successful! Please Click Login to Login and View the Weather";
                        //Clear the Form
                        txtUserName.Text = "";
                        txtEmail.Text = "";
                        txtPassword.Text = "";
                    }
                    else
                    {
                        lblRegistrationMessage.Text = "This Email is already Registered. Please Click Login";
                    }

                }
                else
                {
                    lblRegistrationMessage.Text = "This UserName already exists. Please Enter a Unique UserName";
                }

            }
            catch(Exception ex)
            {
                lblRegistrationMessage.Text = "Could Not Register " + ex.Message.ToString() + ". Please Try again Later";
            }

        }
    }
}