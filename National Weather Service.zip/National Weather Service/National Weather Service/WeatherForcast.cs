﻿using Newtonsoft.Json.Linq;
using System;
using System.Net;

namespace National_Weather_Service
{
    public class WeatherForcast
    {
        public string number { get; set; }
        public string name { get; set; }
        public DateTime startTime { get; set; }
        public DateTime endTime { get; set; }
        public Boolean isDaytime { get; set; }
        public int temperature { get; set; }
        public string temperatureUnit { get; set; }
        public string temperatureTrend { get; set; }
        public string windSpeed { get; set; }
        public string windDirection { get; set; }
        public string icon { get; set; }
        public string shortForecast { get; set; }
        public string detailedForecast { get; set; }

        public static WeatherForcast GetWeather(int iWeatherNumber)
        {
            WeatherForcast weather = new WeatherForcast();
            try
            {
                //Get the JSON From the API
                JObject json = GetJSON();
                if (json != null)
                {
                    //Query the JSON for the selected Number
                    weather = QueryJSON(iWeatherNumber, json);
                }
                return weather;
            }
            catch
            {
                return weather;
            }
            finally
            {
                
            }

        }

        private static JObject GetJSON()
        {
            try
            {
                string apiUrl = "https://api.weather.gov/gridpoints/TOP/33,36/forecast";
                //Set the Headers and Download the JSON from the URL
                using (WebClient wc = new WebClient())
                {
                    wc.Headers.Add("User-Agent: Other");
                    return JObject.Parse(wc.DownloadString(apiUrl));
                }
            }
            catch
            {
                return null;
            }
        }

        private static WeatherForcast QueryJSON(int iWeatherNumber, JObject json)
        {
            WeatherForcast weather = new WeatherForcast();
            try
            {
                //Query the JSON 
                JToken currentweather = json.SelectToken("properties.periods[?(@.number == " + iWeatherNumber +")]");

                //Set the Values for the new Weather Object
                weather.name = currentweather["name"].ToString();
                weather.startTime = Convert.ToDateTime(currentweather["startTime"].ToString());
                weather.endTime = Convert.ToDateTime(currentweather["startTime"].ToString());
                weather.isDaytime = Convert.ToBoolean(currentweather["isDaytime"].ToString());
                weather.temperature = Convert.ToInt32(currentweather["temperature"].ToString());
                weather.temperatureUnit = currentweather["temperatureUnit"].ToString();
                weather.temperatureTrend = currentweather["temperatureTrend"].ToString();
                weather.windSpeed = currentweather["windSpeed"].ToString();
                weather.windDirection = currentweather["windDirection"].ToString();
                weather.icon = currentweather["icon"].ToString();
                weather.shortForecast = currentweather["shortForecast"].ToString();
                weather.detailedForecast = currentweather["detailedForecast"].ToString();
                return weather;

    }
            catch (Exception ex)
            {
                return weather;
            }
        }


    }
}