﻿CREATE TABLE [dbo].[Registration] (
    [Username] VARCHAR (100) NULL,
    [Email]    VARCHAR (100) NULL,
    [Password] VARCHAR (20)  NULL
);

